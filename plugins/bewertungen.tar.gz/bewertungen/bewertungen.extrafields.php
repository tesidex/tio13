<?php

/* ====================
  [BEGIN_COT_EXT]
  Hooks=admin.extrafields.first
  [END_COT_EXT]
  ==================== */

/**
 * Bewertungen system for Cotonti
 *
 * @package bewertungen
 * @version 0.9.8
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */
defined('COT_CODE') or die('Wrong URL');

require_once cot_incfile('bewertungen', 'plug');

$extra_whitelist[$db_bew] = array(
	'name' => $db_bew,
	'caption' => $L['Plugin'].' Bewertungen system',
	'type' => 'plug',
	'code' => 'bewertungen',
	'tags' => array(
		'bewertungen.tools.tpl' => '{ADMIN_BEWERTUNGEN_XXXXX}, {ADMIN_BEWERTUNGEN_XXXXX_TITLE}',
		'bewertungen.tpl' => '{BEWERTUNGEN_FORM_XXXXX}, {BEWERTUNGEN_FORM_XXXXX_TITLE}, {BEWERTUNGEN_ROW_XXXXX} {BEWERTUNGEN_ROW_XXXXX_TITLE}',
	)
);

?>