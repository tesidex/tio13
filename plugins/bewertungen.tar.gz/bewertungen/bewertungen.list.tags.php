<?php
/* ====================
[BEGIN_COT_EXT]
Hooks=page.list.tags
Tags=page.list.tpl:{LIST_BEWERTUNGEN},{LIST_BEWERTUNGEN_DISPLAY}
[END_COT_EXT]
==================== */

/**
 * Comments system for Cotonti
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL');

require_once cot_incfile('bewertungen', 'plug');

$t->assign(array(
	'LIST_BEWERTUNGEN' => cot_bewertungen_link('page', 'c='.$c, 'page', $c),
	'LIST_BEWERTUNGEN_COUNT' => cot_bewertungen_count('page', $c),
	'LIST_BEWERTUNGEN_DISPLAY' => cot_bewertungen_display('page', $c)
));

?>