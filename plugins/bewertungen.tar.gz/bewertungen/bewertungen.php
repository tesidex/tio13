<?php

/* ====================
 * [BEGIN_COT_EXT]
 * Hooks=standalone
 * [END_COT_EXT]
 */

/**
 * Bewertungen system for Cotonti
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */
defined('COT_CODE') && defined('COT_PLUG') or die('Wrong URL');

require_once cot_incfile('bewertungen', 'plug');
require_once cot_incfile('forms');

$m = cot_import('m', 'G', 'ALP');
$a = cot_import('a', 'G', 'ALP');
$id = (int) cot_import('id', 'G', 'INT');
$item = cot_import('item', 'G', 'TXT');
$cat = cot_import('cat', 'G', 'TXT');
$area = cot_import('area', 'G', 'ALP');

$out['subtitle'] = $L['bewertungen_bewertungen'];

// Get area/item/cat by id
if ($id > 0)
{
	$res = $db->query("SELECT bew_code, bew_area FROM $db_bew WHERE bew_id = $id");
	if ($res->rowCount() == 1)
	{
		$row = $res->fetch();
		$area = $row['bew_area'];
		$item = $row['bew_code'];
	}
}

// Check if bewertungen are enabled for specific category/item
cot_block(!empty($area) && !empty($item) && cot_bewertungen_enabled($area, $cat, $item));

$url_area = $_SESSION['cot_bew_back'][$area][$cat][$item][0];
$url_params = $_SESSION['cot_bew_back'][$area][$cat][$item][1];
cot_block(!empty($url_area));

// Try to fetch $force_admin from session
if (isset($_SESSION['cot_bewertungen_force_admin'][$area][$item]) && $_SESSION['cot_bewertungen_force_admin'][$area][$item]
	&& $usr['auth_read'] && $usr['auth_write'])
{
	$usr['isadmin'] = true;
}

if ($m == 'edit' && $id > 0)
{
	if ($a == 'update' && $id > 0)
	{
		/* == Hook == */
		foreach (cot_getextplugins('bewertungen.edit.update.first') as $pl)
		{
			include $pl;
		}
		/* ===== */

		$sql1 = $db->query("SELECT * FROM $db_bew WHERE bew_id=? AND bew_code=? LIMIT 1", array($id, $item));
		cot_die($sql1->rowCount() == 0);
		$row = $sql1->fetch();

		$time_limit = ($sys['now'] < ($row['bew_date'] + $cfg['plugin']['bewertungen']['time'] * 60)) ? TRUE : FALSE;
		$usr['isowner'] = $time_limit
			&& ($usr['id'] > 0 && $row['bew_authorid'] == $usr['id']
			|| $usr['id'] == 0 && $usr['ip'] == $row['bew_authorip']);
		$usr['allow_write'] = ($usr['isadmin'] || $usr['isowner']);
		cot_block($usr['allow_write']);

		$bewarray['bew_text'] = cot_import('bewtext', 'P', 'HTM');

		if (mb_strlen($bewarray['bew_text']) < $cfg['plugin']['bewertungen']['minsize'])
		{
			cot_error($L['bew_bewertentooshort'], 'bewtext');
		}

		foreach ($cot_extrafields[$db_bew] as $exfld)
		{
			$bewarray['bew_' . $exfld['field_name']] = cot_import_extrafields('rbewertungen' . $exfld['field_name'], $exfld);
		}

		if (!cot_error_found())
		{
			$sql = $db->update($db_bew, $bewarray, 'bew_id=? AND bew_code=?', array($id, $item));

			cot_extrafield_movefiles();

			if ($cfg['plugin']['bewertungen']['mail'])
			{
				$sql2 = $db->query("SELECT * FROM $db_users WHERE user_maingrp=5");

				$email_title = $L['plu_bewlive'];
				$email_body = $L['User'] . ' ' . preg_replace('#[^\w\p{L}]#u', '', $usr['name']) . ', ' . $L['plu_bewlive3'];
				$email_body .= COT_ABSOLUTE_URL . cot_url($url_area, $url_params, '#c' . $id, true) . "\n\n";

				while ($adm = $sql2->fetch())
				{
					cot_mail($adm['user_email'], $email_title, $email_body);
				}
				$sql2->closeCursor();
			}
			/* == Hook == */
			foreach (cot_getextplugins('bewertungen.edit.update.done') as $pl)
			{
				include $pl;
			}
			/* ===== */

			$bew_grp = ($usr['isadmin']) ? 'adm' : 'usr';
			cot_log('Edited bewerten #' . $id, $bew_grp);
			cot_redirect(cot_url($url_area, $url_params, '#c' . $id, true));
		}
	}
	$t->assign(array(
		'BEWERTUNGEN_TITLE' => $plugin_title,
		'BEWERTUNGEN_TITLE_URL' => cot_url('plug', 'e=bewertungen')
	));
	$t->parse('MAIN.BEWERTUNGEN_TITLE');

	$sql = $db->query("SELECT * FROM $db_bew WHERE bew_id=? AND bew_code=? AND bew_area=?", array($id, $item, $area));
	cot_die($sql->rowCount() != 1);
	$bew = $sql->fetch();

	$bew_limit = ($sys['now'] < ($bew['bew_date'] + $cfg['plugin']['bewertungen']['time'] * 60)) ? TRUE : FALSE;
	$usr['isowner'] = $bew_limit
		&& ($usr['id'] > 0 && $bew['bew_authorid'] == $usr['id'] || $usr['id'] == 0
		&& isset($_SESSION['cot_bewertungen_edit'][$id]));

	$usr['allow_write'] = ($usr['isadmin'] || $usr['isowner']);
	cot_block($usr['allow_write']);

	$t->assign(array(
		'BEWERTUNGEN_FORM_POST' => cot_url('plug', 'e=bewertungen&m=edit&a=update&area=' . $area . '&cat=' . $cat . '&item=' . $bew['bew_code'] . '&id=' . $bew['bew_id']),
		'BEWERTUNGEN_POSTER_TITLE' => $L['Poster'],
		'BEWERTUNGEN_POSTER' => $bew['bew_author'],
		'BEWERTUNGEN_IP_TITLE' => $L['Ip'],
		'BEWERTUNGEN_IP' => $bew['bew_authorip'],
		'BEWERTUNGEN_DATE_TITLE' => $L['Date'],
		'BEWERTUNGEN_DATE' => cot_date('datetime_medium', $bew['bew_date']),
		'BEWERTUNGEN_DATE_STAMP' => $bew['bew_date'],
		'BEWERTUNGEN_FORM_UPDATE_BUTTON' => $L['Update'],
		'BEWERTUNGEN_FORM_TEXT' => cot_textarea('bewtext', $bew['bew_text'], 8, 64, '', 'input_textarea_minieditor')
	));

	// Extra fields
	foreach ($cot_extrafields[$db_bew] as $exfld)
	{
		$uname = strtoupper($exfld['field_name']);
		$exfld_val = cot_build_extrafields('rbewertungen' . $exfld['field_name'], $exfld, $bew[$exfld['field_name']]);
		$exfld_title = isset($L['bewertungen_' . $exfld['field_name'] . '_title']) ? $L['bewertungen_' . $exfld['field_name'] . '_title'] : $exfld['field_description'];
		$t->assign(array(
			'BEWERTUNGEN_FORM_' . $uname =>  $exfld_val,
			'BEWERTUNGEN_FORM_' . $uname . '_TITLE' => $exfld_title,
			'BEWERTUNGEN_FORM_EXTRAFLD' => $exfld_val,
			'BEWERTUNGEN_FORM_EXTRAFLD_TITLE' => $exfld_title
			));
		$t->parse('BEWERTUNGEN.BEWERTUNGEN_FORM_EDIT.EXTRAFLD');
	}

	/* == Hook == */
	foreach (cot_getextplugins('bewertungen.edit.tags') as $pl)
	{
		include $pl;
	}
	/* ===== */

	$t->parse('MAIN.BEWERTUNGEN_FORM_EDIT');
}

if ($a == 'send' && $usr['auth_write'])
{
	cot_shield_protect();
	$rtext = cot_import('rtext', 'P', 'HTM');
	$rname = cot_import('rname', 'P', 'TXT');
	$bewarray = array();
	// Extra fields
	foreach ($cot_extrafields[$db_bew] as $exfld)
	{
		$bewarray['bew_' . $exfld['field_name']] = cot_import_extrafields('rbewertungen' . $exfld['field_name'], $exfld);
	}

	/* == Hook == */
	foreach (cot_getextplugins('bewertungen.send.first') as $pl)
	{
		include $pl;
	}
	/* ===== */

	if (empty($rname) && $usr['id'] == 0)
	{
		cot_error($L['bew_authortooshort'], 'rname');
	}
	if (mb_strlen($rtext) < $cfg['plugin']['bewertungen']['minsize'])
	{
		cot_error($L['bew_bewertentooshort'], 'rtext');
	}
	if ($cfg['plugin']['bewertungen']['bewertungenize'] && mb_strlen($rtext) > $cfg['plugin']['bewertungen']['bewertungenize'])
	{
		cot_error($L['bew_bewertentoolong'], 'rtext');
	}

	if (!cot_error_found())
	{
		$bewarray['bew_area'] = $area;
		$bewarray['bew_code'] = $item;
		$bewarray['bew_author'] = ($usr['id'] == 0) ? $rname : $usr['name'];
		$bewarray['bew_authorid'] = (int) $usr['id'];
		$bewarray['bew_authorip'] = $usr['ip'];
		$bewarray['bew_text'] = $rtext;
		$bewarray['bew_date'] = (int) $sys['now'];

		$sql = $db->insert($db_bew, $bewarray);
		$id = $db->lastInsertId();

		cot_extrafield_movefiles();

		$_SESSION['cot_bewertungen_edit'][$id] = $sys['now'];

		if ($cfg['plugin']['bewertungen']['mail'])
		{
			$sql = $db->query("SELECT * FROM $db_users WHERE user_maingrp=5");
			$email_title = $L['plu_bewlive'];
			$email_body = $L['User'] . ' ' . preg_replace('#[^\w\p{L}]#u', '', ($usr['id'] == 0 ? $rname : $usr['name'])) . ', ' . $L['plu_bewlive2'];
			$email_body .= COT_ABSOLUTE_URL . cot_url($url_area, $url_params, '#c' . $id, true) . "\n\n";
			while ($adm = $sql->fetch())
			{
				cot_mail($adm['user_email'], $email_title, $email_body);
			}
			$sql->closeCursor();
		}

		/* == Hook == */
		foreach (cot_getextplugins('bewertungen.send.new') as $pl)
		{
			include $pl;
		}
		/* ===== */


		cot_message($L['bew_bewertenadded']);

		cot_shield_update(20, 'New bewerten');

		cot_redirect(cot_url($url_area, $url_params, '#c' . $id, true));
	}
	cot_redirect(cot_url($url_area, $url_params, '#bewertungen', true));
}
elseif ($a == 'delete' && $usr['isadmin'])
{
	cot_check_xg();
	$sql = $db->query("SELECT * FROM $db_bew WHERE bew_id=$id AND bew_area='$area' LIMIT 1");

	if ($row = $sql->fetch())
	{
		$sql->closeCursor();
		$sql = $db->delete($db_bew, "bew_id=$id");

		foreach ($cot_extrafields[$db_bew] as $exfld)
		{
			cot_extrafield_unlinkfiles($row['bew_' . $exfld['field_name']], $exfld);
		}

		/* == Hook == */
		foreach (cot_getextplugins('bewertungen.delete') as $pl)
		{
			include $pl;
		}
		/* ===== */

		cot_log('Deleted bewerten #' . $id . ' in &quot;' . $item . '&quot;', 'adm');
	}
	cot_redirect(cot_url($url_area, $url_params, '#bewertungen', true));
}
elseif ($a == 'enable' && $usr['isadmin'])
{
	$area = cot_import('area', 'P', 'ALP');
	$state = cot_import('state', 'P', 'INT');
}

cot_display_messages($t);
?>