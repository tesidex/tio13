<?php
/* ====================
[BEGIN_COT_EXT]
Hooks=polls.viewall.tags
Tags=polls.tpl:{POLLS_BEWERTUNGEN}
[END_COT_EXT]
==================== */

/**
 * Bewertungen system for Cotonti
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL');

require_once cot_incfile('bewertungen', 'plug');

$t->assign(array(
	'POLLS_BEWERTUNGEN' => cot_bewertungen_link('polls', 'id='.$row['poll_id'], 'polls', $row['poll_id']),
	'POLLS_BEWERTUNGEN_COUNT' => cot_bewertungen_count('polls', $row['poll_id'])
));

?>