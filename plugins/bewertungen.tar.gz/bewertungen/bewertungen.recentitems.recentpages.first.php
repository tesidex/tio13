<?php
/* ====================
[BEGIN_COT_EXT]
Hooks=recentitems.recentpages.first
[END_COT_EXT]
==================== */

/**
 * Joins into the main recentitems query
 *
 * @package bewertungen
 * @version 0.9.1
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL');

global $db_bew;

require_once cot_incfile('bewertungen', 'plug');

$join_columns .= ", (SELECT COUNT(*) FROM `$db_bew` WHERE bew_area = 'page' AND bew_code = p.page_id) AS bew_count";

?>
