<?php
/* ====================
[BEGIN_COT_EXT]
Code=bewertungen
Name=Bewertungen system
Category=community-social
Description=Bewertungen system for Cotonti
Version=0.9.7
Date=2011-09-23
Author=Cotonti Team
Copyright=Partial copyright (c) Cotonti Team 2008-2012
Notes=BSD License
Auth_guests=R
Lock_guests=12345A
Auth_members=RW
Lock_members=
Recommends_modules=page,polls,rss
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
time=01:select:1,2,3,4,5,6,7,8,9,10,15,30,60,90,120,180:10:Bewertungen editable timeout for users, minutes
mail=02:radio:0,1:0:Notify about new bewertungen by email?
rss_bewertenmaxsymbols=05:string:::Bewertungen. Cut element description longer than N symbols, Disabled by default
expand_bewertungen=06:radio:0,1:1:Expand bewertungen, Show bewertungen expanded by default
maxbewertungenperpage=07:string::15:Max. bewertungen on page
bewertungenize=08:string::0:Max. size of bewerten, In bytes (zero for unlimited size). Default - 0
countbewertungen=09:radio:0,1:1:Count bewertungen, Display the count of bewertungen near the icon
parsebbcodebew=10:radio:0,1:1:Parse BBcode in bewertungen
parsesmiliesbew=11:radio:0,1:1:Parse smilies in bewertungen
markup=12:radio::1:Enable markup in bewertungen
minsize=13:string::2:Min. bewerten size
order=14:select:Chronological,Recent:Recent:Bewerten sorting order
[END_COT_EXT_CONFIG]
==================== */

/**
 * Bewertungen system plugins
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL');

?>