<?php
/* ====================
[BEGIN_COT_EXT]
Hooks=statistics.tags
Tags=statistics.tpl:{STATISTICS_TOTALDBBEWERTUNGEN}
[END_COT_EXT]
==================== */

/**
 * Comments system for Cotonti
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL');

require_once cot_incfile('bewertungen', 'plug');

$totaldbbewertung = $db->countRows($db_bew);
$t->assign(array(
	'STATISTICS_TOTALDBBEWERTUNGEN' => $totaldbbewertung
));

?>