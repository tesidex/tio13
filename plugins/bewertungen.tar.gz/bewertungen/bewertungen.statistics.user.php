<?php
/* ====================
[BEGIN_COT_EXT]
Hooks=statistics.user
Tags=statistics.tpl:{STATISTICS_USER_BEWERTUNGEN}
[END_COT_EXT]
==================== */

/**
 * Bewertungen system for Cotonti
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL');

require_once cot_incfile('bewertungen', 'plug');

$sql = $db->query("SELECT COUNT(*) FROM $db_bew WHERE bew_authorid=".$usr['id']);
$user_bewertungen = $sql->fetchColumn();
$t->assign(array(
	'STATISTICS_USER_BEWERTUNGEN' => $user_bewertung
));

?>