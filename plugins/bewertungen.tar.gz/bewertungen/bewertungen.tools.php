<?php
/* ====================
[BEGIN_COT_EXT]
Hooks=tools
[END_COT_EXT]
==================== */

/**
 * Administration panel - Manager of bewertungen
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */

(defined('COT_CODE') && defined('COT_ADMIN')) or die('Wrong URL.');

list($usr['auth_read'], $usr['auth_write'], $usr['isadmin']) = cot_auth('plug', 'bewertungen');
cot_block($usr['isadmin']);

require_once cot_incfile('bewertungen', 'plug');

$t = new XTemplate(cot_tplfile('bewertungen.tools', 'plug', true));

$adminhelp = $L['plu_help_bewertungen'];

list($pg, $d, $durl) = cot_import_pagenav('d', $cfg['maxrowsperpage']);

/* === Hook  === */
foreach (cot_getextplugins('admin.bewertungen.first') as $pl)
{
	include $pl;
}
/* ===== */

if ($a == 'delete')
{
	cot_check_xg();
	$db->delete($db_bew, "bew_id=$id");

	$adminwarnings = ($sql) ? $L['adm_bewe_already_del'] : $L['Error'];
}

$is_adminwarnings = isset($adminwarnings);

$totalitems = $db->countRows($db_bew);

$pagenav = cot_pagenav('admin', 'm=other&p=bewertungen', $d, $totalitems, $cfg['maxrowsperpage'], 'd', '', $cfg['jquery'] && $cfg['turnajax']);

$sql = $db->query("SELECT * FROM $db_bew WHERE 1 ORDER BY bew_id DESC LIMIT $d, ".$cfg['maxrowsperpage']);

$ii = 0;
/* === Hook - Part1 : Set === */
$extp = cot_getextplugins('admin.bewertungen.loop');
/* ===== */
foreach ($sql->fetchAll() as $row)
{
	$row['bew_text'] = htmlspecialchars(cot_cutstring(strip_tags($row['bew_text']), 40));
	$row['bew_type'] = mb_substr($row['bew_code'], 0, 1);
	$row['bew_value'] = $row['bew_code'];

	switch ($row['bew_area'])
	{
		case 'page':
			$row['bew_url'] = cot_url('page', "c=system&id=".$row['bew_value']."&bewertungen=1", "#c".$row['bew_id']);
		break;

		case 'weblogs':
			$row['bew_url'] = cot_url('plug', 'e=weblogs&m=page&id='.$row['bew_value'], '#c'.$row['bew_id']);
		break;

		case 'gal':
			$row['bew_url'] = cot_url('plug', 'e=gal&pic='.$row['bew_value'], '#c'.$row['bew_id']);
		break;

		case 'users':
			$row['bew_url'] = cot_url('users', 'm=details&id='.$row['bew_value'], '#c'.$row['bew_id']);
		break;

		case 'polls':
			$row['bew_url'] = cot_url('polls', 'id='.$row['bew_value']."&bewertungen=1", '#c'.$row['bew_id']);
		break;

		case 'e_shop':
			$row['bew_url'] = cot_url('plug', 'e=e_shop&sh=product&productID='.$row['bew_value'], '#c'.$row['bew_id']);
		break;

		default:
			$row['bew_url'] = '';
		break;
	}

	$t->assign(array(
		'ADMIN_BEWERTUNGEN_ITEM_DEL_URL' => cot_url('admin', 'm=other&p=bewertungen&a=delete&id='.$row['bew_id'].'&'.cot_xg()),
		'ADMIN_BEWERTUNGEN_ITEM_ID' => $row['bew_id'],
		'ADMIN_BEWERTUNGEN_CODE' => $row['bew_code'],
		'ADMIN_BEWERTUNGEN_AREA' => $row['bew_area'],
		'ADMIN_BEWERTUNGEN_AUTHOR' => $row['bew_author'],
		'ADMIN_BEWERTUNGEN_DATE' => cot_date('datetime_medium', $row['bew_date']),
		'ADMIN_BEWERTUNGEN_DATE_STAMP' => $row['bew_date'],
		'ADMIN_BEWERTUNGEN_TEXT' => $row['bew_text'],
		'ADMIN_BEWERTUNGEN_URL' => $row['bew_url'],
		'ADMIN_BEWERTUNGEN_ODDEVEN' => cot_build_oddeven($ii)
	));

	if (isset($cot_extrafields[$db_bew]))
	{
		foreach ($cot_extrafields[$db_bew] as $exfld)
		{
			$tag = mb_strtoupper($exfld['field_name']);
			$t->assign(array(
				'ADMIN_BEWERTUNGEN_' . $tag . '_TITLE' => isset($L['bewertung_' . $exfld['field_name'] . '_title']) ? $L['bewertung_' . $exfld['field_name'] . '_title'] : $exfld['field_description'],
				'ADMIN_BEWERTUNGEN_' . $tag => cot_build_extrafields_data('bewertungen', $exfld, $row['bew_'.$exfld['field_name']]),
			));
		}
	}

	/* === Hook - Part2 : Include === */
	foreach ($extp as $pl)
	{
		include $pl;
	}
	/* ===== */
	$t->parse('MAIN.ADMIN_BEWERTUNGEN_ROW');
	$ii++;
}

$t->assign(array(
	'ADMIN_BEWERTUNGEN_CONFIG_URL' => cot_url('admin', 'm=config&n=edit&o=plug&p=bewertungen'),
	'ADMIN_BEWERTUNGEN_ADMINWARNINGS' => $adminwarnings,
	'ADMIN_BEWERTUNGEN_PAGINATION_PREV' => $pagenav['prev'],
	'ADMIN_BEWERTUNGEN_PAGNAV' => $pagenav['main'],
	'ADMIN_BEWERTUNGEN_PAGINATION_NEXT' => $pagenav['next'],
	'ADMIN_BEWERTUNGEN_TOTALITEMS' => $totalitems,
	'ADMIN_BEWERTUNGEN_COUNTER_ROW' => $ii
));

/* === Hook  === */
foreach (cot_getextplugins('admin.bewertungen.tags') as $pl)
{
	include $pl;
}
/* ===== */

$t->parse('MAIN');
if (COT_AJAX)
{
	$t->out('MAIN');
}
else
{
	$adminmain = $t->text('MAIN');
}

?>