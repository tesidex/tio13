<?php
/**
 * Parameters for bewertungen config implantation into modules
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */

// Options for implantation
$bew_options = array(
	array(
		'name' => 'enable_bewertungen',
		'type' => COT_CONFIG_TYPE_RADIO,
		'default' => '1'
	)
);

// Modules list to implant into their root config
$bew_modules_list = array('polls');

// Module list to implant into their structure config
$bew_modules_struct_list = array('page');
?>
