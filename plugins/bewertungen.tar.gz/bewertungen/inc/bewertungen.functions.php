<?php
/**
 * Comments system for Cotonti
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2009-2012
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL');

// Requirements
global $R, $L;
require_once cot_incfile('users', 'module');
require_once cot_langfile('bewertungen', 'plug');
require_once cot_incfile('bewertungen', 'plug', 'resources');
require_once cot_incfile('forms');

// Table name globals
global $db_bew, $db_x;
$db_bew = (isset($db_bew)) ? $db_bew : $db_x . 'bew';
$cot_extrafields[$db_bew] = (!empty($cot_extrafields[$db_bew]))	? $cot_extrafields[$db_bew] : array();
/**
 * Returns number of bewertungen for item
 *
 * @param string $ext_name Target extension name
 * @param string $code Item code
 * @param array $row Database row entry (optional)
 * @return int
 * @global CotDB $db
 */
function cot_bewertungen_count($ext_name, $code, $row = array())
{
	global $db, $db_bew;
	static $bew_cache = array();

	if (isset($bew_cache[$ext_name][$code]))
	{
		return $bew_cache[$ext_name][$code];
	}

	$cnt = 0;
	if (isset($row['bew_count']))
	{
		$cnt = (int) $row['bew_count'];
		$bew_cache[$ext_name][$code] = $cnt;
	}
	else
	{
		$sql = $db->query("SELECT COUNT(*) FROM $db_bew WHERE bew_area = ? AND bew_code = ?", array($ext_name, $code));
		if ($sql->rowCount() == 1)
		{
			$cnt = (int) $sql->fetchColumn();
			$bew_cache[$ext_name][$code] = $cnt;
		}
	}

	return $cnt;
}

/**
 * Generates bewertungen display for a given item
 *
 * @param string $ext_name Module or plugin code
 * @param string $code Item identifier
 * @param string $cat Item category code (optional)
 * @param bool $force_admin Enforces user to be administrator of bewertungen for this item.
 *	E.g. to moderate his wall even if he is not a moderator
 * @return string Rendered HTML output for bewertungen
 * @global CotDB $db
 */
function cot_bewertungen_display($ext_name, $code, $cat = '', $force_admin = false)
{
	global $db, $db_bew, $db_users, $cfg, $usr, $L, $sys, $R, $env, $pg, $cot_extrafields;

	// Check permissions and enablement
	list($auth_read, $auth_write, $auth_admin) = cot_auth('plug', 'bewertungen');

	if ($auth_read && $auth_write && $force_admin)
	{
		$auth_admin = true;
		$_SESSION['cot_bewertungen_force_admin'][$ext_name][$code] = true;
	}

	$enabled = cot_bewertungen_enabled($ext_name, $cat, $code);

	if (!$auth_read || !$enabled && !$auth_admin)
	{
		return '';
	}

	// Get the URL and parameters
	$link_area = $env['ext'];
	$link_params = $_GET;
	if (defined('COT_PLUG'))
	{
		$link_area = 'plug';
		$link_params['e'] = $env['ext'];
	}
	if (isset($_GET['rwr']))
	{
		unset($link_params['rwr'], $link_params['e']);
	}

	$_SESSION['cot_bew_back'][$ext_name][$cat][$code] = array($link_area, $link_params);

	$d_var = 'dcm';
	list($pg, $d, $durl) = cot_import_pagenav($d_var, $cfg['plugin']['bewertungen']['maxbewertungenperpage']);
	$d = empty($d) ? 0 : (int) $d;

	if ($auth_write && $enabled)
	{
		require_once cot_incfile('forms');
	}

	$t = new XTemplate(cot_tplfile('bewertungen', 'plug'));

	/* == Hook == */
	foreach (cot_getextplugins('bewertungen.main') as $pl)
	{
		include $pl;
	}
	/* ===== */

	$t->assign(array(
		'BEWERTUNGEN_CODE' => $code,
		'BEWERTUNGEN_FORM_SEND' => cot_url('plug', "e=bewertungen&a=send&area=$ext_name&cat=$cat&item=$code"),
		'BEWERTUNGEN_FORM_AUTHOR' => ($usr['id'] > 0) ? $usr['name'] : cot_inputbox('text', 'rname'),
		'BEWERTUNGEN_FORM_AUTHORID' => $usr['id'],
		'BEWERTUNGEN_FORM_TEXT' => $auth_write && $enabled ? cot_textarea('rtext', $rtext, 10, 120, '', 'input_textarea_minieditor')
			: '',
		'BEWERTUNGEN_DISPLAY' => $cfg['plugin']['bewertungen']['expand_bewertungen'] ? '' : 'none'
	));

	if ($auth_write && $enabled)
	{
		// Extra fields
		foreach ($cot_extrafields[$db_bew] as $exfld)
		{
			$uname = strtoupper($exfld['field_name']);
			$exfld_val = cot_build_extrafields('rbewertungen' . $exfld['field_name'], $exfld, $rbewertungen[$exfld['field_name']]);
			$exfld_title = isset($L['bewertungen_' . $exfld['field_name'] . '_title']) ? $L['bewertungen_' . $exfld['field_name'] . '_title'] : $exfld['field_description'];
			$t->assign(array(
				'BEWERTUNGEN_FORM_' . $uname => $exfld_val,
				'BEWERTUNGEN_FORM_' . $uname . '_TITLE' => $exfld_title,
				'BEWERTUNGEN_FORM_EXTRAFLD' => $exfld_val,
				'BEWERTUNGEN_FORM_EXTRAFLD_TITLE' => $exfld_title
				));
			$t->parse('BEWERTUNGEN.BEWERTUNGEN_NEWCOMMENT.EXTRAFLD');
		}

		$allowed_time = cot_build_timegap($sys['now'] - $cfg['plugin']['bewertungen']['time'] * 60,
			$sys['now']);
		$bew_hint = cot_rc('bew_edithint', array('time' => $allowed_time));

		/* == Hook == */
		foreach (cot_getextplugins('bewertungen.newbewerten.tags') as $pl)
		{
			include $pl;
		}
		/* ===== */

		$usr['id'] == 0 && $t->parse('BEWERTUNGEN.BEWERTUNGEN_NEWCOMMENT.GUEST');
		cot_display_messages($t, 'BEWERTUNGEN.BEWERTUNGEN_NEWCOMMENT');
		$t->assign('BEWERTUNGEN_FORM_HINT', $bew_hint);
		$t->parse('BEWERTUNGEN.BEWERTUNGEN_NEWCOMMENT');
	}
	else
	{
		$warning = $enabled ? $L['bew_regonly'] : $L['bew_closed'];
		$t->assign('BEWERTUNGEN_CLOSED', $warning);
		$t->parse('BEWERTUNGEN.BEWERTUNGEN_CLOSED');
	}

	$order = $cfg['plugin']['bewertungen']['order'] == 'Chronological' ? 'ASC' : 'DESC';
	$bewertungen_order = "bew_id $order";

	/* == Hook == */
	foreach (cot_getextplugins('bewertungen.query') as $pl)
	{
		include $pl;
	}
	/* ===== */

	$sql = $db->query("SELECT c.*, u.* $bewertungen_join_columns
		FROM $db_bew AS c LEFT JOIN $db_users AS u ON u.user_id = c.bew_authorid $bewertungen_join_tables
		WHERE bew_area = ? AND bew_code = ? $bewertungen_join_where ORDER BY $bewertungen_order LIMIT ?, ?",
		array($ext_name, $code, (int) $d, (int) $cfg['plugin']['bewertungen']['maxbewertungenperpage']));
	if ($sql->rowCount() > 0 && $enabled)
	{
		$i = $d;
		$kk = 0;
		$totalitems = cot_bewertungen_count($ext_name, $code);
		/* === Hook - Part1 : Set === */
		$extp = cot_getextplugins('bewertungen.loop');
		/* ===== */

		foreach ($sql->fetchAll() as $row)
		{
			$i++;
			$kk++;
			$bew_admin = ($auth_admin) ? cot_rc('bewertungen_code_admin', array(
					'ipsearch' => cot_build_ipsearch($row['bew_authorip']),
					'delete_url' => cot_confirm_url(cot_url('plug', 'e=bewertungen&a=delete&cat='.$cat.'&id='.$row['bew_id'].'&'.cot_xg()), 'bewertungen', 'bewertungen_confirm_delete')
				)) : '';

			$bew_text = cot_parse($row['bew_text'], $cfg['plugin']['bewertungen']['markup']);

			$time_limit = ($sys['now'] < ($row['bew_date'] + $cfg['plugin']['bewertungen']['time'] * 60)) ? TRUE
				: FALSE;
			$usr['isowner_bew'] = $time_limit && ($usr['id'] > 0 && $row['bew_authorid'] == $usr['id']
				|| $usr['id'] == 0 && $usr['ip'] == $row['bew_authorip']);
			$bew_gup = $sys['now'] - ($row['bew_date'] + $cfg['plugin']['bewertungen']['time'] * 60);
			$allowed_time = ($usr['isowner_bew'] && !$usr['isadmin']) ? ' - '
				. cot_build_timegap($sys['now'] + $bew_gup, $sys['now']) . $L['plu_bewgup'] : '';
			$bew_edit = ($auth_admin || $usr['isowner_bew']) ? cot_rc('bewertungen_code_edit', array(
					'edit_url' => cot_url('plug', 'e=bewertungen&m=edit&cat='.$cat.'&id='.$row['bew_id']),
					'allowed_time' => $allowed_time
				)) : '';

			$t->assign(array(
				'BEWERTUNGEN_ROW_ID' => $row['bew_id'],
				'BEWERTUNGEN_ROW_ORDER' => $cfg['plugin']['bewertungen']['order'] == 'Recent' ? $totalitems - $i + 1 : $i,
				'BEWERTUNGEN_ROW_URL' => cot_url($link_area, $link_params, '#c'.$row['bew_id']),
				'BEWERTUNGEN_ROW_AUTHOR' => cot_build_user($row['bew_authorid'], htmlspecialchars($row['bew_author'])),
				'BEWERTUNGEN_ROW_AUTHORID' => $row['bew_authorid'],
				'BEWERTUNGEN_ROW_TEXT' => $bew_text,
				'BEWERTUNGEN_ROW_DATE' => cot_date('datetime_medium', $row['bew_date']),
				'BEWERTUNGEN_ROW_DATE_STAMP' => $row['bew_date'],
				'BEWERTUNGEN_ROW_ADMIN' => $bew_admin,
				'BEWERTUNGEN_ROW_EDIT' => $bew_edit,
				'BEWERTUNGEN_ROW_ODDEVEN' => cot_build_oddeven($kk),
				'BEWERTUNGEN_ROW_NUM' => $kk
			));

				// Extrafields
			if (isset($cot_extrafields[$db_bew]))
			{
				foreach ($cot_extrafields[$db_bew] as $exfld)
				{
					$tag = mb_strtoupper($exfld['field_name']);
					$t->assign(array(
						'BEWERTUNGEN_ROW_' . $tag . '_TITLE' => isset($L['bewertungen_' . $exfld['field_name'] . '_title']) ? $L['bewertungen_' . $exfld['field_name'] . '_title'] : $exfld['field_description'],
						'BEWERTUNGEN_ROW_' . $tag => cot_build_extrafields_data('bewertungen', $exfld, $row['bew_'.$exfld['field_name']]),
					));
				}
			}

			$t->assign(cot_generate_usertags($row, 'BEWERTUNGEN_ROW_AUTHOR_'), htmlspecialchars($row['bew_author']));

			/* === Hook - Part2 : Include === */
			foreach ($extp as $pl)
			{
				include $pl;
			}
			/* ===== */

			$t->parse('BEWERTUNGEN.BEWERTUNGEN_ROW');
		}

		$pagenav = cot_pagenav($link_area, $link_params, $d, $totalitems,
			$cfg['plugin']['bewertungen']['maxbewertungenperpage'], $d_var, '#bewertungen',
			$cfg['jquery'] && $cfg['ajax_enabled'], 'bewertungen', 'plug', "e=bewertungen&area=$ext_name&cat=$cat&item=$code");
		$t->assign(array(
			'BEWERTUNGEN_PAGES_INFO' => cot_rc('bewertungen_code_pages_info', array(
					'totalitems' => $totalitems,
					'onpage' => $i - $d
				)),
			'BEWERTUNGEN_PAGES_TOTALITEMS' => $totalitems,
			'BEWERTUNGEN_PAGES_PAGESPREV' => $pagenav['prev'],
			'BEWERTUNGEN_PAGES_PAGNAV' => $pagenav['main'],
			'BEWERTUNGEN_PAGES_PAGESNEXT' => $pagenav['next']
		));
		$t->parse('BEWERTUNGEN.PAGNAVIGATOR');

	}
	elseif (!$sql->rowCount() && $enabled)
	{
		$t->assign(array(
			'BEWERTUNGEN_EMPTYTEXT' => $L['bew_nobewertungenyet'],
		));
		$t->parse('BEWERTUNGEN.BEWERTUNGEN_EMPTY');
	}


	/* == Hook == */
	foreach (cot_getextplugins('bewertungen.tags') as $pl)
	{
		include $pl;
	}
	/* ===== */

	$t->parse('BEWERTUNGEN');
	$res_display = $t->text('BEWERTUNGEN');

	return $res_display;
}

/**
 * Checks if bewertungen are enabled for specific extension and category
 *
 * @param string $ext_name Extension name
 * @param string $cat Category name or empty if checking the entire area
 * @param string $item Item code, not yet supported
 * @return bool
 */
function cot_bewertungen_enabled($ext_name, $cat = '', $item = '')
{
	global $cfg, $cot_modules;
	if (isset($cfg[$ext_name][$cat]['enable_bewertungen'])
		|| isset($cfg[$ext_name]['enable_bewertungen'])
		|| isset($cfg['plugin'][$ext_name]['enable_bewertungen']))
	{
		if (isset($cot_modules[$ext_name]))
		{
			return (bool) (isset($cfg[$ext_name][$cat]['enable_bewertungen']) ? $cfg[$ext_name][$cat]['enable_bewertungen']
				: $cfg[$ext_name]['enable_bewertungen']);
		}
		else
		{
			return (bool) $cfg['plugin'][$ext_name]['enable_bewertungen'];
		}
	}
	return true;
}

/**
 * Generates bewertungen display for a given item
 *
 * @param string $link_area Target URL area for cot_url()
 * @param string $link_params Target URL params for cot_url()
 * @param string $ext_name Module or plugin code
 * @param string $code Item identifier
 * @param string $cat Item category code (optional)
 * @param array $row Database row entry (optional)
 * @return string Rendered HTML output for bewertungen
 * @see cot_bewertungen_count()
 * @global CotDB $db
 */
function cot_bewertungen_link($link_area, $link_params, $ext_name, $code, $cat = '', $row = array())
{
	global $cfg, $db, $R, $L, $db_bew;

	if (!cot_bewertungen_enabled($ext_name, $cat, $code))
	{
		return '';
	}

	$res = cot_rc('bewertungen_link', array(
		'url' => cot_url($link_area, $link_params, '#bewertungen'),
		'count' => $cfg['plugin']['bewertungen']['countbewertungen'] ? cot_bewertungen_count($ext_name, $code, $row) : ''
	));
	return $res;
}

/**
 * New bewertungen count for admin page
 *
 * @param string $timeback Datetime to count from
 * @return int
 * @global CotDB $db
 */
function cot_bewertungen_newcount($timeback)
{
	global $db, $db_bew;

	$sql = $db->query("SELECT COUNT(*) FROM $db_bew WHERE bew_date > ?", array($timeback));
	$newbewertungen = $sql->fetchColumn();
	return $newbewertungen;
}

/**
 * Removes bewertungen associated with an item
 *
 * @param string $area Item area code
 * @param string $code Item identifier
 * @global CotDB $db
 */
function cot_bewertungen_remove($area, $code)
{
	global $db, $db_bew;

	$db->delete($db_bew, 'bew_area = ? AND bew_code = ?', array($area, $code));
}

?>
