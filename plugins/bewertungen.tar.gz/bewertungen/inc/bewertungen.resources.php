<?php
/**
 * Static and dynamic resource (e.g. HTML) strings. Can be overriden by skin files and other code.
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2009-2012
 * @license BSD
 */

$R['bewertungen_code_admin'] = $L['Ip'].': {$ipsearch}<span class="spaced">'.$cfg['separator'].'</span><a href="{$delete_url}" class="confirmLink">'.$L['Delete'].'</a><span class="spaced">'.$cfg['separator'].'</span>';
$R['bewertungen_code_edit'] = '<a href="{$edit_url}">'.$L['Edit'].'</a> {$allowed_time}';
$R['bewertungen_code_pages_info'] = $L['Total'].': {$totalitems}, '.$L['comm_on_page'].': {$onpage}';
$R['bewertungen_link'] = '<a href="{$url}" class="bewertungen_link" alt="'.$L['Bewertungen'].'">'.$R['icon_bewertungen'].' ({$count})</a>';

$R['icon_bewertungen'] = 
	'<img class="icon" src="images/icons/'.$cfg['defaulticons'].'/bewertungen.png" alt="'.$L['Bewertungen'].'" />';
$R['icon_bewertungen_cnt'] = 
	'<img class="icon" src="images/icons/'.$cfg['defaulticons'].'/bewertungen.png" alt="'.$L['Bewertungen'].'" /> ({$cnt})';

?>
