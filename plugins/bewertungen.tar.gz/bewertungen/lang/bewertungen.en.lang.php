<?php
/**
 * English Language File for Bewertungen Plugin
 *
 * @package bewetrungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL.');

/**
 * Plugin Config
 */

$L['cfg_enable_bewetrungen'] = array('Enable bewetrungen');
$L['cfg_mail'] = array('Notify about new bewetrungen via email');
$L['cfg_markitup'] = array('Use markitup');
$L['cfg_markup'] = array('Enable markup');
$L['cfg_minsize'] = array('Min. bewerten length');
$L['cfg_time'] = array('Bewertungen editable timeout for users', 'in minutes');
$L['cfg_rss_bewertenmaxsymbols'] = array('Bewertungen. Cut element description longer than N symbols', 'Disabled by default');
$L['cfg_expand_bewetrungen'] = array('Expand bewetrungen', 'Show bewetrungen expanded by default');
$L['cfg_maxbewetrungenperpage'] = array('Max. bewetrungen on page', ' ');
$L['cfg_bewetrungenize'] = array('Max. size of bewerten, bytes', '0 for unlimited size');
$L['cfg_countbewetrungen'] = array('Count bewetrungen', 'Display number of bewetrungen near the icon');
$L['cfg_order'] = array('Sorting order', 'Chronological or most recent first');
$L['cfg_order_params'] = array('Chronological', 'Recent');
$L['cfg_parsebbcodebew'] = array('Parse BBcodes in bewetrungen', '');
$L['cfg_parsesmiliesbew'] = array('Parse smilies in bewetrungen', '');

$L['info_desc'] = 'Bewertungen system for Cotonti with API and integration with pages, lists, polls, RSS and other extensions';

/**
 * Plugin Body
 */

$L['bewetrungen_bewerten'] = 'Comment';
$L['bewetrungen_bewetrungen'] = 'Bewertungen';
$L['bewetrungen_confirm_delete'] = 'Do you really want to delete this bewerten?';
$L['Newbewerten'] = 'New bewerten';

$L['bewe_on_page'] = 'on page';

$L['bew_closed'] = 'Adding bewetrungen has been disabled for this item';
$L['bew_bewertenadded'] = 'Done, bewerten added';
$L['bew_bewertentoolong'] = 'The bewerten is too long';
$L['bew_bewertentooshort'] = 'The bewerten is too short or missing';
$L['bew_nobewetrungenyet'] = 'No bewetrungen yet';
$L['bew_authortooshort'] = 'Poster name is too short';
$L['bew_regonly'] = 'Only registered users can post new bewetrungen';

$L['plu_bewgup'] = ' left';
$L['bew_edithint'] = 'Your bewerten will be available for editing for {$time}';

$L['plu_bewlive'] = 'New bewerten on our site';
$L['plu_bewlive1'] = 'Edited bewerten on the site';
$L['plu_bewlive2'] = 'left a bewerten:';
$L['plu_bewlive3'] = 'has edited the bewerten:';
$L['rss_bewetrungen'] = 'Bewertungen for';
$L['rss_bewerten_of_user'] = 'Comment from';
$L['rss_bewetrungen_item_desc'] = 'Last bewetrungen on page';
$L['rss_original'] = 'Original message';

/**
 * Admin Section
 */

$L['home_newbewetrungen'] = 'New bewetrungen';
$L['core_bewetrungen'] = &$L['Bewertungen'];
$L['adm_bewe_already_del'] = 'Comment deleted';

/**
 * cot_declension Arrays
 */

$Ls['Bewertungen'] = array('bewetrungen','bewerten');

/**
 * Comedit
 */

$L['plu_title'] = 'Comment Editing';

?>