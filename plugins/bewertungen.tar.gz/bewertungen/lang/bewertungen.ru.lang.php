<?php
/**
 * Russian Language File for Bewertungen Plugin
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL.');

/**
 * Plugin Config
 */

$L['cfg_bewertungenize'] = array('Макс. размер комментария, байт', '0 - без ограничения размера');
$L['cfg_countbewertungen'] = array('Считать комментарии', 'Показывать количество комментариев рядом с иконкой');
$L['cfg_enable_bewertungen'] = array('Включить комментарии');
$L['cfg_expand_bewertungen'] = array('Открыть комментарии', 'По умолчанию показывать комментарии на странице');
$L['cfg_mail'] = array('Отсылать email-уведомления администратору о новых комментариях');
$L['cfg_markitup'] = array('Использовать markitup');
$L['cfg_markup'] = array('Включить разметку');
$L['cfg_maxbewertungenperpage'] = array('Макс. количество комментариев на странице', ' ');
$L['cfg_minsize'] = array('Мин. длина комментария');
$L['cfg_order'] = array('Порядок сортировки', 'Хронологический или самые последние вверху');
$L['cfg_order_params'] = array('Хронологический', 'Cамые последние вверху');
$L['cfg_parsebbcodebew'] = array('Парсинг BBCode в комментариях', ' ');
$L['cfg_parsesmiliesbew'] = array('Парсинг смайликов в комментариях', ' ');
$L['cfg_rss_bewertenmaxsymbols'] = array('Макс. количество символов для комментариев', 'По умолчанию отключено');
$L['cfg_time'] = array('Пользователи могут редактировать комментарии в течение', 'минут');

$L['info_desc'] = 'Комментарии с API и интеграцией со страницами, списками, опросами, RSS и другими расширениями';

/**
 * Plugin Body
 */

$L['bewertungen_bewerten'] = 'Комментарий';
$L['bewertungen_bewertungen'] = 'Комментарии';
$L['bewertungen_confirm_delete'] = 'Вы действительно хотите удалить этот комментарий?';
$L['Newbewerten'] = 'Новый комментарий';

$L['bewe_on_page'] = 'на странице';

$L['bew_closed'] = 'Для этого элемента нельзя добавлять комментарии';
$L['bew_bewertenadded'] = 'Комментарий добавлен';
$L['bew_bewertentoolong'] = 'Комментарий слишком длинный';
$L['bew_bewertentooshort'] = 'Комментарий слишком короткий либо отсутствует';
$L['bew_nobewertungenyet'] = 'Комментарии отсутствуют';
$L['bew_authortooshort'] = 'Имя автора слишком короткое';
$L['bew_regonly'] = 'Добавление комментариев доступно только зарегистрированным пользователям';

$L['plu_bewgup'] = ' осталось';
$L['bew_edithint'] = 'Для редактирования комментария осталось {$time}';

$L['plu_bewlive'] = 'Новый коментарий на сайте ';
$L['plu_bewlive1'] = 'Отредактирован коментарий на сайте ';
$L['plu_bewlive2'] = 'оставил комментарий:';
$L['plu_bewlive3'] = 'отредактировал свой комментарий:';
$L['rss_bewertungen'] = 'Комментарии для';
$L['rss_bewerten_of_user'] = 'Комментарий пользователя';
$L['rss_bewertungen_item_desc'] = 'Лента комментариев страницы';
$L['rss_original'] = 'Комментируемая страница';

/**
 * Admin Section
 */

$L['home_newbewertungen'] = 'Новые комментарии';
$L['core_bewertungen'] = &$L['Bewertungen'];
$L['adm_bewe_already_del'] = 'Комментарий удален';

/**
 * cot_declension arrays
 */

$Ls['Bewertungen'] = array('комментарий','комментария','комментариев');

/**
 * Comedit
 */

$L['plu_title'] = 'Редактирование комментария';

?>