<?php
/**
 * Installs bewertungen into modules
 *
 * @package bewertungen
 * @version 0.7.0
 * @author Cotonti Team
 * @copyright Copyright (c) Cotonti Team 2008-2012
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL');

require cot_incfile('bewertungen', 'plug', 'enablement');

// Add options into module configs
foreach ($bew_modules_list as $mod_name)
{
	if (cot_extension_installed($mod_name) && !cot_config_implanted($mod_name, 'bewertungen'))
	{
		cot_config_implant($mod_name, $bew_options, false, 'bewertungen');
	}
}

// Add options into module structure configs
foreach ($bew_modules_struct_list as $mod_name)
{
	if (cot_extension_installed($mod_name) && !cot_config_implanted($mod_name, 'bewertungen'))
	{
		cot_config_implant($mod_name, $bew_options, true, 'bewertungen');
	}
}
?>
