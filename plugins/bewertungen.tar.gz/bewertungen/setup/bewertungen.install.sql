/* Bewertungen schema */

-- Main bewertungen table
CREATE TABLE IF NOT EXISTS `cot_bew` (
	`bew_id` int(11) NOT NULL auto_increment,
	`bew_code` varchar(255) collate utf8_unicode_ci NOT NULL default '',
	`bew_area` varchar(64) collate utf8_unicode_ci NOT NULL default '',
	`bew_author` varchar(100) collate utf8_unicode_ci NOT NULL,
	`bew_authorid` int(11) default NULL,
	`bew_authorip` varchar(15) collate utf8_unicode_ci NOT NULL default '',
	`bew_text` text collate utf8_unicode_ci NOT NULL,
	`bew_date` int(11) NOT NULL default '0',
	`bew_count` int(11) NOT NULL default '0',
	`bew_isspecial` tinyint(1) NOT NULL default '0',
	PRIMARY KEY (`bew_id`),
	KEY (`bew_area`, `bew_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;