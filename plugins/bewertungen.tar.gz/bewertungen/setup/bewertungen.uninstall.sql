/* Drops all bewertungen data bewpletely */
DROP TABLE IF EXISTS `cot_bew`;