/* 0.7.0.1 Enablement now controlled via config */
DROP TABLE IF EXISTS `cot_bew_settings`;