<?php

/* ====================
  [BEGIN_COT_EXT]
  Hooks=tools
  [END_COT_EXT]
  ==================== */

/**
 * Creates aliases in existing pages with empty alias
 *
 * @package converter
 * @version 0.9.12
 * @author Kiryl
 * @copyright (c) Tesidex
 * @license BSD
 */
(defined('COT_CODE') && defined('COT_ADMIN')) or die('Wrong URL.');
$t = new XTemplate(cot_tplfile('converter.admin', 'plug', true));
require_once cot_incfile('page', 'module');
require_once cot_incfile('converter', 'plug');

$a = cot_import('button', 'P', 'TXT');
$source_table = cot_import('source_list', 'P', 'TXT');
$target_table = cot_import('target_list', 'P', 'TXT');

//source_db_list
$source_values = array('blogs_posts','users');
$source_titles = array('Blogs Posts','Users');

$target_values = array('cot_pages','cot_users');
$target_titles = array('cot_pages','cot_users');
$t->assign(array(
    'SOURCE_DB_LIST' => cot_radiobox($source_values[0], 'source_list', $source_values, $source_titles),
    'TARGET_DB_LIST' => cot_selectbox($target_values[0], 'target_list', $target_values, $target_titles),
));



switch ($a) {

     case 'begin':
	  $source_table_arr = $db->query("SELECT * FROM $source_table ORDER BY id")->fetchAll();
	  if ($source_table == 'blogs_posts') {
	       convertBlogs($source_table_arr, $target_table);
	  } elseif ($source_table == 'users') {
	       convertUsers($source_table_arr, $target_table);
	  }
	  break;

     case 'delete':
	  if ($source_table == 'blogs_posts') {
	       deleteBlogs($target_table);
	  } elseif ($source_table == 'users') {
	       deleteUsers($target_table);
	  }
	  break;
}

//$db2 = extraDB('localhost', $port, 'shop', 'root', ''); //connects one more database


$t->parse('MAIN');
if (COT_AJAX) {
     $t->out('MAIN');
} else {
     $adminmain = $t->text('MAIN');
}
?>