<?php

/**
 * Converter Plugin API
 *
 * @package converter
 * @version 0.9.12
 * @author Cotonti Team
 * @copyright (c) 2008-2012 Cotonti Team
 * @license BSD
 */
defined('COT_CODE') or die('Wrong URL');

/**
 * Copies blogs to target cotonti table
 *
 * @param array $source_table_arr An array fetched blogs table
 * @param string $target_table Cotonti table where to insert
 */
function convertBlogs($source_table_arr, $target_table) {
     global $db;
     cot_extrafield_add($target_table, 'is_comment', 'radio', '', '0, 1', '', '', '', '', '');
     cot_extrafield_add($target_table, 'subject', 'input', '', '', '', '', '', '', '');

     foreach ($source_table_arr as $value) {

	  $blogs['page_subject'] = $value['subject'];
	  $blogs['page_is_comment'] = $value['is_comment'];
	  $blogs['page_ownerid'] = $value['user_id'];
	  $blogs['page_title'] = $value['title'];
	  $blogs['page_desc'] = $value['description'];
	  $blogs['page_text'] = $value['body'];
	  $blogs['page_id'] = $value['id'];
	  $blogs['page_date'] = strtotime($value['created_at']);
	  $blogs['page_begin'] = strtotime($value['created_at']); //page
	  $blogs['page_updated'] = strtotime($value['updated_at']);
	  $db->insert($target_table, $blogs);
     }
}

/**
 * Copies users to target cotonti table
 *
 * @param array $source_table_arr An array fetched users table
 * @param string $target_table Cotonti table where to insert
 *
 * @global CotDB $db
 */
function convertUsers($source_table_arr, $target_table) {
     global $db;
     
     cot_extrafield_add($target_table, 'city', 'input', '', '', '', '', '', '', '');
     cot_extrafield_add($target_table, 'firstname', 'input', '', '', '', '', '', '', '');
     cot_extrafield_add($target_table, 'surname', 'input', '', '', '', '', '', '', '');
     cot_extrafield_add($target_table, 'business_scope', 'input', '', '', '', '', '', '', '');
     cot_extrafield_add($target_table, 'forum_user_id', 'input', '', '', '', '', '', '', '');
     
     $groups_arr = array('1'  => '5',
			 '2'  => '1',
			 '3'  => '7',
			 '4'  => '9',
			 '5'  => '8',
			 '6'  => '10',
			 '7'  => '6',
			 '8'  => '11'
	 );

     foreach ($source_table_arr as $value) {
	  
	  $users['user_maingrp'] =  $groups_arr[$value['group_id']];
	  $users['user_id'] = $value['id'];
	  $users['user_forum_user_id'] = $value['forum_user_id'];
	  $users['user_name'] = $value['login'];
	  $users['user_firstname'] = $value['name'];
	  $users['user_surname'] = $value['surname'];
	  $users['user_business_scope'] = $value['business_scope'];
	  $users['user_regdate'] = strtotime($value['created_at']);
	  $users['user_password'] = $value['password'];
	  $users['user_birthdate'] = $value['birthday'];
	  $users['user_email'] = $value['email'];
	  $users['user_country'] = $value['country'];
	  $users['user_city'] = $value['city'];
	  $users['user_lastip'] = $value['ip'];
	  $users['user_passfunc'] = 'md5';
	  $res = $db->insert($target_table, $users);
     }
     
}

/**
 * Deletes blogs from target cotonti table
 *
 * @param string $target_table Cotonti table where to insert
 * @return bool
 *
 * @global CotDB $db
 */
function deleteBlogs($target_table) {
     global $db;

     cot_extrafield_remove($target_table, 'is_comment');
     cot_extrafield_remove($target_table, 'subject');
     
     $res = $db->query("TRUNCATE TABLE $target_table");
     return $res;
     
}

/**
 * Deletes users from target cotonti table
 *
 * @param string $target_table Cotonti table where to delete
 * @return bool
 * 
 * @global CotDB $db
 */
function deleteUsers($target_table) {
     global $db;

     cot_extrafield_remove($target_table, 'city');
     cot_extrafield_remove($target_table, 'surname');
     cot_extrafield_remove($target_table, 'business_scope');
     cot_extrafield_remove($target_table, 'forum_user_id');
     cot_extrafield_remove($target_table, 'firstname');
     
     $res = $db->query("DELETE FROM $target_table
			WHERE user_id<>1");
     return $res;
}

/**
 * Creates object for database connection
 *
 * @param string $host Database host name
 * @param string $port Database port if exists
 * @param string $name Database name 
 * @param string $name Database user name
 * @param string $name Database user password  
 */
function extraDB($host, $port, $name, $user, $password) {
     $dbc_port = empty($port) ? '' : ';port=' . $port;
     return new CotDB('mysql:host=' . $host . $dbc_port . ';dbname=' . $name, $user, $password);
}

?>