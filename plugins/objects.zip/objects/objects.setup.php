<?php


/**
 * [BEGIN_COT_EXT]
 * Code=objects
 * Name=Generate objects
 * Description=Generate objects for belarus.tio.by
 * Notes=Generate objects for belarus.tio.by
 * Version=0.9.13
 * Date=2013-04-18
 * Author=ElNinjo
 * Copyright=tesidex.com
 * Auth_guests=R
 * Lock_guests=2345A
 * Auth_members=RW
 * Requires_modules=page
 * [END_COT_EXT]

==================== */


defined('COT_CODE') or die('Wrong URL');

