<?php
/* ====================
[BEGIN_COT_EXT]
Hooks=page.list.query
[END_COT_EXT]
==================== */

defined('COT_CODE') or die('Wrong URL');


//cot_print($newspaper_id );
if ($c == $cfg['plugin']['pagearchive']['cat']) {
     require_once cot_langfile('pagearchive', 'plug');
     // Selection filter by category
     $pa_cats = preg_split('#,\s*#', $cfg['plugin']['pagearchive']['cats']);

     $pa_catsub = array();
     foreach ($pa_cats as $pa_cat) {
	  $pa_catsub = array_merge($pa_catsub, cot_structure_children('page', $pa_cat));
     }

     $newspaper_id = cot_import('newspaper_id', 'G', 'ALP');

     $where['cat'] = "page_cat IN ('" . implode("','", $pa_catsub) . "')";
     $where['newspaper_id'] = "page_newspaper_id = $newspaper_id";



     if (!empty($newspaper_id)) {
	  $list_url_path['newspaper_id'] = $newspaper_id;
     }
}