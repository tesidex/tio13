<?php
/* ====================
[BEGIN_COT_EXT]
Code=pageavatar
Name=Page Avatar
Description=Page Avatar plugin enables you to upload, replace and delete images for a specific page bypassing PFS
Version=4.03
Date=2013-02-05
Author=esclkm, Seditio.by
Copyright=&copy; esclkm
Notes=
Auth_guests=R
Lock_guests=W12345A
Auth_members=RW
Lock_members=
Requires_modules=page
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
set=01:textarea:::Format settings cat|path|thumb-x-y|reqiured|ext
field=02:string::avatar:field name
[END_COT_EXT_CONFIG]
==================== */

/**
 * Pageavatar for Cotonti CMF
 *
 * @version 4.00
 * @author  esclkm
 * @copyright (c) 2011 esclkm
 */

defined('COT_CODE') or die('Wrong URL.');

?>