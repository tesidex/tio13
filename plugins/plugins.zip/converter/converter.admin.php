<?php

/* ====================
  [BEGIN_COT_EXT]
  Hooks=tools
  [END_COT_EXT]
  ==================== */

/**
 * Creates aliases in existing pages with empty alias
 *
 * @package converter
 * @version 0.9.12
 * @author Kiryl
 * @copyright (c) Tesidex
 * @license BSD
 */
(defined('COT_CODE') && defined('COT_ADMIN')) or die('Wrong URL.');
$t = new XTemplate(cot_tplfile('converter.admin', 'plug', true));
require_once cot_incfile('page', 'module');
require_once cot_incfile('converter', 'plug');

$a = cot_import('button', 'P', 'TXT');
$convert_option = cot_import('convert_options_list', 'P', 'TXT');
$delete_option = cot_import('delete_options_list', 'P', 'TXT');
global $db, $db_structure;


if ($a == 'begin') {



     switch ($convert_option) {
	  case 'blogs':
	       $source_table = 'blogs_posts';
	       $target_table = $db_pages;
	       $res = convertBlogs($source_table, $target_table);
	       cot_check($res == false, 'Something went wrong when converting blogs');
	       break;
	  case 'users':
	       $source_table = 'users';
	       $target_table = $db_users;
	       $res = convertUsers($source_table, $target_table);
	       cot_check($res == false, 'Something went wrong when converting users');
	       break;
	  case 'belarus':
	       $target_table = 'bel_pages';
               addExtrafieldsBelarus ($target_table);                  
	       $res1 = convertArchitecture('sf_architecture', $target_table);
	       $res2 = convertLocation('sf_locations', $target_table);
	       $res3 = convertDistrict('sf_region_description', $target_table);
	       cot_check($res1 == false || $res2 == false || $res3 == false, 'Something went wrong when converting');
	       break;
     }
     
     if (!cot_error_found()) {
	  cot_message($res1.' архитектурных объектов конвертировано<br>'.$res2.' городов конвертировано<br>'.$res3.' районов конвертировано');
     }
     
} elseif ($a == 'delete') {

     switch ($delete_option) {
	  case 'blogs': 
	       $target_table = $db_pages;
	       $res = deleteBlogs($target_table);
	       cot_check($res == false,'Something went wrong when deleting blogs');
	       break;
	  case 'users':
	       $target_table = $db_users;
	       $res = deleteUsers($target_table);
	       cot_check($res == false,'Something went wrong when deleting users');
	       break;
	  case 'belarus':
	       $target_table = $db_pages;
	       $res = deleteBelarus($target_table);
	       cot_check($res == false,'Something went wrong when deleting blogs');
	       break;
     }
     if (!cot_error_found()) {
	  cot_message($target_table.' deleted');
     }
}

//source_db_list
switch ($cfg['mainurl']) {
     case 'http://belarus.tio.by':
	  $values_array = array('belarus');
	  $convert_titles_array = array('Belarus');
	  $delete_titles_array = array('Belarus');
	  break;
     case 'http://tio.by':
	  $values_array = array('blogs', 'users');
	  $convert_titles_array = array('Blogs Posts To Cot_Pages', 'Users to Cot_Users');
	  $delete_titles_array = array('Pages', 'Users');
	  break;
     default :
	  $values_array = array('blogs', 'users', 'belarus');
	  $convert_titles_array = array('Blogs Posts To Cot_Pages', 'Users to Cot_Users', 'Belarus');
	  $delete_titles_array = array('Pages', 'Users', 'Belarus');
}


$t->assign(array(
    'CONVERT_VARIANTS_LIST' => cot_radiobox($values_array[0], 'convert_options_list', $values_array, $convert_titles_array,'','<br>'),
    'DELETE_VARIANTS_LIST' => cot_radiobox($values_array[0], 'delete_options_list', $values_array, $delete_titles_array,'','<br>'),
));

//$db2 = extraDB('localhost','','tio','root','12345');

cot_display_messages($t);
$t->parse('MAIN');
if (COT_AJAX) {
     $t->out('MAIN');
} else {
     $adminmain = $t->text('MAIN');
}
?>