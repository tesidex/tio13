<?php
/* ====================
[BEGIN_COT_EXT]
Code=converter
Name=converter
Description=Transitions Tio database
Version=0.9.12
Date=2013-02-06
Author=Kiryl
Copyright=(c) Tesidex 2012-2013
Notes=BSD License
Auth_guests=R
Lock_guests=W12345A
Auth_members=RW
Lock_members=12345
[END_COT_EXT]

==================== */

defined('COT_CODE') or die('Wrong URL');

?>
