<?php

/** 
 * [BEGIN_COT_EXT]
 * Hooks=page.tags
 * [END_COT_EXT]
 */
 
/**
 * plugin Generate objects for Cotonti Siena
 * 
 * @package objects
 * @version 0.9.13
 * @author ElNinjo
 * @copyright tesidex.com
 * @license BSD
 *  */


defined('COT_CODE') or die('Wrong URL.');

//require_once cot_langfile('objects', 'plug');
//require_once cot_incfile('objects', 'plug');
require_once cot_incfile('objects', 'plug', 'resources');
//cot_print($pag['page_cat']);

if ( $pag['page_cat'] == 'architecture' )   {

    $architectures = $db -> query("SELECT *
				FROM $db_pages
				WHERE page_cat = 'architecture' AND
				page_location_id = ?",$pag['page_location_id'])
		-> fetchAll();

    if (empty($architectures))  cot_print('$architectures пуста: ',$architectures);
    else    {
	$kk = 0;
	foreach ($architectures as $loc)
	{
		$kk++;
		$t->assign(cot_generate_pagetags($loc, 'ARCHITECTURES_ROW_', 0, $usr['isadmin']));
		$t->parse('MAIN.ARCHITECTURES_ROW');
	}
    }
}


if ( $pag['page_cat'] == 'location' )   {	//&& ()

    $locations = $db -> query("SELECT *
				FROM $db_pages
				WHERE page_cat = 'location' AND
				page_district_id = ?",$pag['page_district_id'])
		-> fetchAll();

    if (empty($locations))  cot_print('$locations пуста: ',$locations);
    else    {
	$kk = 0;
	foreach ($locations as $loc)
	{
		$kk++;
		$t->assign(cot_generate_pagetags($loc, 'LOCATIONS_ROW_', 0, $usr['isadmin']));
		$t->parse('MAIN.LOCATIONS_ROW');
	}
    }
}

if ( $pag['page_cat'] == 'district' )   {
    $districts = $db -> query("SELECT *
				FROM $db_pages
				WHERE page_cat = 'district' AND
				page_region_id = ?",$pag['page_region_id'])
		-> fetchAll();

    if (empty($districts))  cot_print('$districts пуста: ',$districts);
    else    {
	$kk = 0;
	foreach ($districts as $loc)
	{
		$kk++;
		$t->assign(cot_generate_pagetags($loc, 'DISTRICTS_ROW_', 0, $usr['isadmin']));
		$t->parse('MAIN.DISTRICTS_ROW');
	}
    }
}