<?php

/**
 * [BEGIN_COT_EXT]
 * Hooks=page.edit.update.done
 * Order=12
 * [END_COT_EXT]
 */
/**
 * plugin Generate objects for Cotonti Siena
 *
 * @package objects
 * @version 0.9.13
 * @author ElNinjo
 * @copyright tesidex.com
 * @license BSD
 *  */
defined('COT_CODE') or die('Wrong URL.');

//cot_print($rpage);

global $db;
if ($rpage['page_cat'] == 'location') {

    $updres = $db->update('bel_pages',
	    array(
	'page_location_title' => $rpage['page_title'],
	'page_location_alias' => $rpage['page_alias']
	    ), 'page_location_id = ' . $rpage['page_id']);
} elseif ($rpage['page_cat'] == 'district') {

    $updres = $db->update('bel_pages',
	    array(
	'page_district_title' => $rpage['page_title'],
	'page_district_alias' => $rpage['page_alias']
	    ), 'page_district_id = ' . $rpage['page_id']);
} elseif ($rpage['page_cat'] == 'region') {

    $updres = $db->update('bel_pages',
	    array(
	'page_region_title' => $rpage['page_title'],
	'page_region_alias' => $rpage['page_alias']
	    ), 'page_region_id = ' . $rpage['page_id']);
}
if ($updres) cot_watch($updres);
