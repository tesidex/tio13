<?php
/* ====================
[BEGIN_COT_EXT]
Code=urleditor
Name=URL Editor
Category=performance-seo
Description=Advanced URL customizer for your site
Version=0.9.1
Date=2011-08-25
Author=Trustmaster
Copyright=Copyright (c) Vladimir Sibirov and Cotonti Team 2010-2013
Notes=Requires writable datas/urltrans.dat to use Custom presets.
Auth_guests=R
Lock_guests=W12345A
Auth_members=R
Lock_members=
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
preset=01:callback:cot_url_presets():none:URL Preset
[END_COT_EXT_CONFIG]
==================== */

defined('COT_CODE') or die('Wrong URL');
